# clusterability 0.2.1.0
* Sparse PCA can now be used as a dimension reduction method. Both the elasticnet implementation and variable projection implementation are available.

# clusterability 0.1.1.0
* Silverman's Test no longer rounds p-values below 0.005 to 0
* Clean up code for examples and plots
* Add GPL-2 license information to all code files
* Add README and NEWS files

# clusterability 0.1.0.0
* Initial release
